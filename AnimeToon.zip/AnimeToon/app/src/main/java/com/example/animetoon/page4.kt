package com.example.animetoon

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animetoon.databinding.ActivityPage4Binding

class page4 : AppCompatActivity() {

    lateinit var binding: ActivityPage4Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage4Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.OnePiece.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.character.setOnClickListener{
            startActivity(Intent(this , AnimePage2::class.java))
        }

        binding.Arcs.setOnClickListener{
            startActivity(Intent(this , page3::class.java))
        }

        binding.Lnks.setOnClickListener{
            startActivity(Intent(this , page4::class.java))
        }

        binding.textView4.setOnClickListener{
            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://aniwatch.to/one-piece-100")
            startActivity(openURL)
        }

        binding.textView5.setOnClickListener {
            //onepiece insta
            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://www.instagram.com/onepiece_staff/#")
            startActivity(openURL)
        }

        binding.textView6.setOnClickListener {
            //odd insa
            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://www.instagram.com/jp.eiichirooda/#")
            startActivity(openURL)
        }

        binding.textView7.setOnClickListener {
            //my insta
            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse("https://www.instagram.com/lakshya_error_404/#")
            startActivity(openURL)
        }

    }
}