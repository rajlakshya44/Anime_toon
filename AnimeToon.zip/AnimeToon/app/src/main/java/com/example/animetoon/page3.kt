package com.example.animetoon

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animetoon.databinding.ActivityPage3Binding

class page3 : AppCompatActivity() {

    lateinit var binding: ActivityPage3Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPage3Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.OnePiece.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.character.setOnClickListener{
            startActivity(Intent(this , AnimePage2::class.java))
        }

        binding.Arcs.setOnClickListener{
            startActivity(Intent(this , page3::class.java))
        }

        binding.Lnks.setOnClickListener{
            startActivity(Intent(this , page4::class.java))
        }

        binding.textView3.text = " 1. East Blue Saga \n 2. Arabasta Saga \n 3. Sky Island Saga \n 4. Water 7 Saga \n 5. Thriller Bark Saga \n 6. Summit War Saga \n 7. Fish-Man Island Saga \n 8. Dressrosa Saga \n 9. Whole Cake Island Saga \n 10. Wano Country Saga \n Saga is upto July 2023"
    }
}