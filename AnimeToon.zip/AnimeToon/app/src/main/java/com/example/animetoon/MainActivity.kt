package com.example.animetoon

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animetoon.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.OnePiece.setOnClickListener{
            val intent = Intent(this, this)
            startActivity(intent)
        }

        binding.character.setOnClickListener{
            startActivity(Intent(this , AnimePage2::class.java))
        }

        binding.Arcs.setOnClickListener{
            startActivity(Intent(this , page3::class.java))
        }

        binding.Lnks.setOnClickListener{
            startActivity(Intent(this , page4::class.java))
        }
    }

    private fun startActivity(intent: Unit) {

    }

    private fun Intent(mainActivity: MainActivity, mainActivity1: MainActivity) {

    }

}