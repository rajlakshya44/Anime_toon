package com.example.animetoon

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.animetoon.databinding.ActivityAnimePage2Binding
import com.example.animetoon.databinding.ActivityMainBinding

class AnimePage2 : AppCompatActivity() {

    lateinit var binding: ActivityAnimePage2Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnimePage2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.OnePiece.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        binding.character.setOnClickListener{
            startActivity(Intent(this , AnimePage2::class.java))
        }

        binding.Arcs.setOnClickListener{
            startActivity(Intent(this , page3::class.java))
        }

        binding.Lnks.setOnClickListener{
            startActivity(Intent(this , page4::class.java))
        }
        var req : Int
        binding.Crue.setOnClickListener{
            binding.textView2.text = "The Straw Hat Pirates, a diverse and spirited group from the \"One Piece\" series, are united by their shared dreams and unwavering camaraderie. Led by the determined Monkey D. Luffy, who seeks to become the Pirate King, the crew is a collection of individuals with distinct personalities and remarkable abilities.\n" +
                    "\n" +
                    "Roronoa Zoro, the crew's first member, is an immensely skilled swordsman aiming to become the world's best. Nami, the talented navigator, dreams of mapping the world's seas. Usopp, a sharpshooter and imaginative storyteller, aspires to become a brave warrior of the sea. Sanji, the expert chef and martial artist, seeks to discover the All Blue, a legendary ocean.\n" +
                    "\n" +
                    "Tony Tony Chopper, a reindeer who consumed the Human-Human Fruit, can take on various forms and hopes to cure any disease. Nico Robin, an enigmatic archaeologist, seeks the truth about the world's history through deciphering Poneglyphs. Franky, a shipwright and cyborg, aims to build and sail a dream ship to the ends of the ocean. Brook, a living skeleton and musician, desires to fulfill promises from his past.\n" +
                    "\n" +
                    "Jimbei, a fish-man and seasoned warrior, contributes his strength and wisdom as the crew's helmsman. Together, these unique individuals form an unbreakable bond as they sail the Grand Line, facing formidable foes, uncovering mysteries, and striving for their individual dreams within the overarching journey to find the fabled One Piece treasure"
        }
        binding.sidecharacter.setOnClickListener {
            binding.textView2.text = "Portgas D. Ace, Luffy's adopted brother, carries immense importance due to his lineage as the son of Gol D. Roger. His fiery Logia-type Devil Fruit powers and his tragic fate have a lasting impact on Luffy and the story.\n" +
                    "\n" +
                    "Trafalgar D. Water Law, a powerful pirate and surgeon, forms an alliance with Luffy to take on the Yonko and change the world. His enigmatic past and abilities, like the Ope Ope no Mi Devil Fruit, make him a key player.\n" +
                    "\n" +
                    "Marshall D. Teach, also known as Blackbeard, is a former member of the Whitebeard Pirates who betrays them and becomes a Yonko. His quest for power and ruthless actions drive major plot developments.\n" +
                    "\n" +
                    "Donquixote Doflamingo, a former Celestial Dragon turned pirate, controls a massive criminal empire. His manipulative nature and complex history impact several arcs, including Dressrosa.\n" +
                    "\n" +
                    "Shanks, one of the Four Emperors, is a pivotal figure. He inspired Luffy to become a pirate, and his influence on the world is substantial.\n" +
                    "\n" +
                    "Dracule Mihawk, the greatest swordsman in the world, shapes Zoro's journey as a swordsman and showcases the highest echelons of power.\n" +
                    "\n" +
                    "These characters, among others like Katakuri, Sabo, and Buggy, contribute to the series' intricate web of relationships, ambitions, and conflicts. They showcase the diverse and captivating world of \"One Piece\" beyond the central crew, leaving lasting impressions on both the story and fans."

        }

    }
}